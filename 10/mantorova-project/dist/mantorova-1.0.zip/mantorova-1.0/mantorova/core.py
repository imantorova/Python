def get_message():
    return 'Hello World!'

def print_message ():
    print (get_message())

if __name__ == '__main__':
    print_message()
